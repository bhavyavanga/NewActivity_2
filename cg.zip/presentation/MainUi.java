package com.cg.presentation;

import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

import com.cg.bean.Item;
import com.cg.bean.Order;
import com.cg.exception.MAException;
import com.cg.service.CustomerOrderService;
import com.cg.service.CustomerOrderServiceImpl;
import com.cg.utility.ItemRepositories;

public class MainUi {

	public static void main(String[] args) {

		System.out.println("Welcome to the Shoppers stop you'll be able to buy products here with so amazing discounted prices");

		CustomerOrderService customerOrder = new CustomerOrderServiceImpl();

		Scanner scanner = null;

		int choice = 0;
		int orderID=0;
		boolean againFlag=false;
		boolean choiceFlag = false;

		do {
			System.out.println("1. Register on the Application");
			System.out.println("2. Exit");

			scanner = new Scanner(System.in);
			System.out.println("Enter your Choice please ^_^ ");
			choice = scanner.nextInt();

			try {
				boolean nameFlag = false;
				choiceFlag = true;
				String name;
				switch (choice) {
				case 1:
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter your good Name please");

						name = scanner.nextLine();
						try {
							customerOrder.isNameValidate(name);
							nameFlag = true;
						} catch (MAException e) {
							nameFlag = false;
							System.err.println(e.getMessage());
						}
					} while (!nameFlag);

					long mobile = 0;
					boolean mobileFlag = false;
					do {
						scanner = new Scanner(System.in);
						System.out.println("Enter your personal Mobile Number please");

						try {
							mobile = scanner.nextLong();
							customerOrder.isMobileValid(mobile);
							mobileFlag = true;
						} catch (MAException e) {
							mobileFlag = false;
							System.err.println(e.getMessage());
						}

					} while (!mobileFlag);

					System.out.println("Hello " + name + " Yipee you've Registered successfully \n Welcome to shoppersStop..!! \n Excited ??");

					int choose = 0;
					boolean chooseFlag = false;
do{
					do {
						System.out.println(" 1. Place Order");
						System.out.println(" 2. Display cart Items");
						System.out.println(" 3. Exit");

						scanner = new Scanner(System.in);
						System.out.println("Enter your Action please");
						choose = scanner.nextInt();
						chooseFlag = true;
						/**
						 * Item variables
						 */
						int itemId = 0;
						boolean itemIdFlag = false;
						int generatOrderId=0;
						switch (choose) {
						case 1:
						{
							try {

								Map<Integer, Item> items = customerOrder.getAllItems();

								Iterator<Integer> iterator = items.keySet().iterator();
								while(iterator.hasNext()) {
									int id = iterator.next();
									Item itemData = items.get(id);
									System.out.println(id + ":" + itemData);
								}		
							} catch (MAException e) {
								System.err.println(e.getMessage());
							}

							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter item Id to add in cart");
								itemId = scanner.nextInt();
									/*
									 * try {
									 * 
									 * customerOrder.isValid(itemId); itemIdFlag = true; } catch (MAException e) {
									 * itemIdFlag = false; System.err.println(e.getMessage()); }
									 */

							} while (!chooseFlag);

							int itemQuantity=0;
							boolean quantityFlag = false;
							do {
								scanner = new Scanner(System.in);
								System.out.println("Enter Quantity please");
								try {
									itemQuantity = scanner.nextInt();
									customerOrder.isQuantityValid(itemQuantity);
									quantityFlag = true;
								} catch (MAException e) {
									quantityFlag = false;
									System.err.println(e.getMessage());
								}catch(InputMismatchException e) {
									System.err.println("Opps!! Please enter only digits");
								}
							} while (!quantityFlag);
							
							//Order orderNew=new Order();
							generatOrderId=(int)( Math.random()*1000);
							boolean orderFlag=false;
							Order order = new Order(generatOrderId, mobile, itemId, itemQuantity);
							order.setOrderId(generatOrderId);
							try {
								orderFlag=customerOrder.addToCart(order);
								//System.out.println(order);
							} catch (MAException e) {
								System.err.println(e.getMessage());
							}
							if(orderFlag) {
								System.out.println(" yahoo!! Item added to cart Succesfully with Order Id" + order.getOrderId());
							}
						}
							break;
						case 2:
						{
								
								  try { 
									  List<Order> order=customerOrder.printOrderedItems();
									  double totalAmount=0;
									  for (Iterator iterator = order.iterator(); iterator.hasNext();) {
										Order order2 = (Order) iterator.next();
										double price = ItemRepositories.itemList.get(order2.getItemId()).getPrice() * order2.getQuantity();
										System.out.println("Order placed with Order Id :  "+order2.getItemId() +"\n" +
												"Your product is : "+ ItemRepositories.itemList.get(order2.getItemId()).getName() + "\n"
												+ "Quantity : "+order2.getQuantity() + "\n" + "Total Price is: "  + price + "\n" +"Order Id of Products: " + generatOrderId);
										
										totalAmount = totalAmount + price;
									}
								  System.out.println("Your net payable amount is :" + totalAmount);
								  } catch (MAException e) { System.err.println(e.getMessage()); }
								 
							//System.out.println(CustomerOrderService.orderMap);
						}
							break;
						case 3:
							System.out.println("Thanks Visit Again tadaa, Hope to see you soon");
							System.exit(0);
							break;
						default:
							System.err.println("Please enter only 1 and 2");
							break;
						}
					} while (!chooseFlag);
					
					do {
						System.out.println("Do you want to continue (Yes/No)");
						scanner=new Scanner(System.in);
						String again=scanner.nextLine();
						if(again.equalsIgnoreCase("yes")) {
							againFlag=true;
							break;
						}else if(again.equalsIgnoreCase("no")) {
							System.out.println("Thankyou");
							againFlag=false;
										break;
						}else {
							System.err.println("Please enter only Yes or No");
				continue;
						}			
					} while (!againFlag);
				}while(againFlag);
					//Item item = new Item();

					break;
				case 2:
					System.out.println("Thanks for your Visit, See you soon");
					System.exit(0);
				default:
					System.err.println("Please enter only 1 and 2");
					break;
				}

			} catch (InputMismatchException e) {
				System.err.println("Please enter only digits");
			}
		} while (!choiceFlag);

	}

	
}
