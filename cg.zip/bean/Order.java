package com.cg.bean;

public class Order {

	private int OrderId;
	private long mobile;
	private int itemId;
	private int quantity;

	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Order(int orderId, long mobile, int itemId, int quantity) {
		super();
		OrderId = orderId;
		this.mobile = mobile;
		this.itemId = itemId;
		this.quantity = quantity;
	}

	public int getOrderId() {
		return OrderId;
	}

	public void setOrderId(int orderId) {
		OrderId = orderId;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	@Override
	public String toString() {
		return "Order [OrderId=" + OrderId + ", mobile=" + mobile + ", itemId=" + itemId + ", quantity=" + quantity
				+ "]";
	}

	
}
