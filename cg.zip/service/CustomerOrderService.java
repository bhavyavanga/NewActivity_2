package com.cg.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.cg.bean.Item;
import com.cg.bean.Order;
import com.cg.exception.MAException;

public interface CustomerOrderService {

	static Map<Integer, Order> orderMap = new HashMap<>();

	boolean isNameValidate(String name) throws MAException;

	boolean isNameValidate(long mobile) throws MAException;

	boolean addToCart(Order item) throws MAException;

	List<Order> printOrderedItems() throws MAException;

	List<Item> getIems() throws MAException;

	boolean isQuantityValid(int itemQuantity) throws MAException;

	public Map<Integer, Item> getAllItems() throws MAException;

	void isValid(int itemid);

	List<Item> getItems() throws MAException;

	boolean isMobileValid(long mobile) throws MAException;
	
}
