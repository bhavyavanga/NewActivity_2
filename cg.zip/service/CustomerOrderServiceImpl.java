package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.bean.Item;
import com.cg.bean.Order;
import com.cg.dao.ItemDao;
import com.cg.dao.ItemDaoImpl;
import com.cg.exception.MAException;

public class CustomerOrderServiceImpl implements CustomerOrderService {

ItemDao itemdao=new ItemDaoImpl();
	
	
	
	
	
	@Override
	public boolean isNameValidate(String name) throws MAException {
		
		String regEx="^[A-Z]{1}[a-zA-Z ]{4,}$";
		boolean nameValidFlag=false;
		if(!Pattern.matches(regEx, name)) {
			throw new MAException("First letter should be capital with atleast 5 characters \n");
		}else {
			nameValidFlag=true;
		}
		
		return nameValidFlag;
	}

	@Override
	public boolean isMobileValid(long mobile) throws MAException {
		String regEx2="^[6-9]{1}[0-9]{9}$";
		String phone=String.valueOf(mobile);
		boolean mobileValidFlag=false;
		if(!Pattern.matches(regEx2, phone)) {
			throw new MAException("Enter Valid Number");
		}else {
			mobileValidFlag=true;
		}
		return mobileValidFlag;
	}

	
	  @Override 
	  public boolean addToCart(Order order) throws MAException { 
	  if(order!=null) {
	  orderMap.put(order.getOrderId(), order);
	  //System.out.println("order added");
	 // System.out.println(orderMap);//inorder to keep the key unique we have used getitem id get the random 
	  return true;
	  }else {
	  return false; }
	  }

	
	@Override
	public List<Order> printOrderedItems() throws MAException {
		
		List<Order> orders =  new ArrayList<Order>();
		for(Map.Entry<Integer, Order> entry : orderMap.entrySet()) {//We can use entry interface
			orders.add(entry.getValue());
		}
		return orders;
	}

	@Override
	public List<Item> getItems() throws MAException {
		
		return itemdao.getItems();
	}

	
	public void isIdValid(int itemId) throws MAException {
		System.out.println(itemId);
		
	}

	@Override
	public boolean isQuantityValid(int itemQuantity) throws MAException {
		
		boolean itemquantityFlag=false;
		if(itemQuantity==0){
			throw new MAException("Quantity can't be zero");
		}else {
			itemquantityFlag=true;
		}
		return itemquantityFlag;
	}

	@Override
	public Map<Integer, Item> getAllItems() throws MAException {
		
		return itemdao.getAllItems();
	}

	@Override
	public void isValid(int itemId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean isNameValidate(long mobile) throws MAException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Item> getIems() throws MAException {
		// TODO Auto-generated method stub
		return null;
	}
}
