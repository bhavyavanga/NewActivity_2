package com.cg.dao;

import java.util.List;
import java.util.Map;

import com.cg.bean.Item;
import com.cg.exception.MAException;
import com.cg.utility.ItemRepositories;

public class ItemDaoImpl implements ItemDao {

	@Override
	public List<Item> getItems() throws MAException {
		
		return null;
	}

	@Override
	public Map<Integer, Item> getAllItems() throws MAException {
		
		return ItemRepositories.getItemList();
	}



}
