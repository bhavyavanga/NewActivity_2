package com.cg.dao;

import java.util.List;
import java.util.Map;

import com.cg.bean.Item;
import com.cg.exception.MAException;

public interface ItemDao {

	List<Item> getItems() throws MAException;

	public Map<Integer, Item> getAllItems()throws MAException;
	
}
